from setuptools import setup

setup(

    name="userPaquete",
    version="1.0",
    description="Sistema carga de datos y loging usuario",
    author="Emmanuel Martin",
    author_email="emmanueldavidmartin@gmail.com",

    packages=["userPaquete"]
)


