from setuptools import setup

setup(

    name="paqueteCliente",
    version="1.0",
    description="Clase cliente para instanciar, con atributos y metodos",
    author="Emmanuel Martin",
    author_email="emmanueldavidmartin@gmail.com",

    packages=["paqueteCliente"]
)
